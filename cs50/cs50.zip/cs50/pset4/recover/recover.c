#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

//defining a byte
typedef uint8_t BYTE;

int main(int argc, char *argv[])
{
    //checking for valid number of command-line arguments
    if (argc != 2)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }
    //file object used to read from file
    FILE *f = fopen(argv[1], "r");
    //file object to write into jpeg file
    FILE *f2 = fopen(argv[1], "r");
    fclose(f2);
    BYTE buffer[512];
    int flag = 1;
    int ctr = 0;
    char filename[80] = { };
    //to check for a valid file to read from
    if (f == NULL)
    {
        printf("Enter a valid file to recover from\n");
        return 1;
    }
    // to loop over the given file and  write into jpeg files
    while (flag == 1)
    {
        //to read 512 byte chunks of memory at a time
        if (fread(buffer, sizeof(BYTE), 512, f) < 512)
        {
            flag = 0;
        }
        //to detect start of a new jpeg file
        if (buffer[0] == 0xff && buffer[1] == 0xd8  && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            //for first jpeg file
            if (ctr == 0)
            {
                //to name file as ###.jpg and write into it
                sprintf(filename, "%03i.jpg", ctr);
                f2 = fopen(filename, "w");
                fwrite(buffer, sizeof(BYTE), 512, f2);
                ctr++;
            }
            else
            {
                //to name file as ###.jpg and write into it
                sprintf(filename, "%03i.jpg", ctr);
                f2 = fopen(filename, "w");
                fwrite(buffer, sizeof(BYTE), 512, f2);
                ctr++;
            }
        }
        //to continue writing into an already opened jpeg file
        else if (ctr > 0)
        {
            fwrite(buffer, sizeof(BYTE), 512, f2);
        }
    }
    //close pending files
    fclose(f2);
    fclose(f);
    return 0;
}
