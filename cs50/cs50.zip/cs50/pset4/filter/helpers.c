#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    float average;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            average = ((float)(image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / 3);
            image[i][j].rgbtRed = round(average);
            image[i][j].rgbtGreen = round(average);
            image[i][j].rgbtBlue = round(average);
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int Red = round((.393 * image[i][j].rgbtRed) + (.769 * image[i][j].rgbtGreen) + (.189 * image[i][j].rgbtBlue));
            int Green = round((.349 * image[i][j].rgbtRed) + (.686 * image[i][j].rgbtGreen) + (.168 * image[i][j].rgbtBlue));
            int Blue = round((.272 * image[i][j].rgbtRed) + (.534 * image[i][j].rgbtGreen) + (.131 * image[i][j].rgbtBlue));
            if (Red > 255)
            {
                image[i][j].rgbtRed = 255;
            }
            else
            {
                image[i][j].rgbtRed = Red;
            }
            if (Green > 255)
            {
                image[i][j].rgbtGreen = 255;
            }
            else
            {
                image[i][j].rgbtGreen = Green;
            }
            if (Blue > 255)
            {
                image[i][j].rgbtBlue = 255;
            }
            else
            {
                image[i][j].rgbtBlue = Blue;
            }
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    int temp;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < (width) / 2; j++)
        {
            temp = image[i][j].rgbtRed;
            image[i][j].rgbtRed = image[i][width - j - 1].rgbtRed;
            image[i][width - j - 1].rgbtRed = temp;
            temp = image[i][j].rgbtGreen;
            image[i][j].rgbtGreen = image[i][width - j - 1].rgbtGreen;
            image[i][width - j - 1].rgbtGreen = temp;
            temp = image[i][j].rgbtBlue;
            image[i][j].rgbtBlue = image[i][width - j - 1].rgbtBlue;
            image[i][width - j - 1].rgbtBlue = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int sum1 = 0, sum2 = 0, sum3 = 0;

            //to blur if not a corner or edge pixel
            if (i != 0 && i != (height - 1) && j != 0 && j != (height - 1))
            {
                // to sum and average the 3x3 box
                for (int l = i - 1; l < i + 2; l++)
                {
                    for (int m = j - 1; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 9);
                image[i][j].rgbtGreen = round(sum2 / 9);
                image[i][j].rgbtBlue = round(sum3 / 9);
            }

            //for corner pixel 1
            else if (i == 0 && j == 0)
            {
                for (int l = i; l < i + 2; l++)
                {
                    for (int m = j ; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 4);
                image[i][j].rgbtGreen = round(sum2 / 4);
                image[i][j].rgbtBlue = round(sum3 / 4);
            }

            //for corner pixel 2
            else if (i == 0 &&  j == width - 1)
            {
                for (int l = i; l < i + 2; l++)
                {
                    for (int m = j - 1 ; m < j + 1; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 4);
                image[i][j].rgbtGreen = round(sum2 / 4);
                image[i][j].rgbtBlue = round(sum3 / 4);
            }

            //for corner pixel 3
            else if (i == height - 1 &&  j == 0)
            {
                for (int l = i - 1; l < i + 1; l++)
                {
                    for (int m = j; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 4);
                image[i][j].rgbtGreen = round(sum2 / 4);
                image[i][j].rgbtBlue = round(sum3 / 4);
            }

            //for corner pixel 4
            else if (i == height - 1 &&  j == width - 1)
            {
                for (int l = i - 1; l < i + 1; l++)
                {
                    for (int m = j - 1; m < j + 1; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 4);
                image[i][j].rgbtGreen = round(sum2 / 4);
                image[i][j].rgbtBlue = round(sum3 / 4);
            }

            //for pixel of edge 1
            else if (i == 0)
            {
                for (int l = i; l < i + 2; l++)
                {
                    for (int m = j - 1; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 6);
                image[i][j].rgbtGreen = round(sum2 / 6);
                image[i][j].rgbtBlue = round(sum3 / 6);
            }

            //for pixel of edge 2
            else if (i == height - 1)
            {
                for (int l = i - 1; l < i + 1; l++)
                {
                    for (int m = j - 1; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 6);
                image[i][j].rgbtGreen = round(sum2 / 6);
                image[i][j].rgbtBlue = round(sum3 / 6);
            }

            //for pixel of edge 3
            else if (j == 0)
            {
                for (int l = i - 1; l < i + 2; l++)
                {
                    for (int m = j; m < j + 2; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 6);
                image[i][j].rgbtGreen = round(sum2 / 6);
                image[i][j].rgbtBlue = round(sum3 / 6);
            }

            //for pixel of edge 4
            else if (j == height - 1)
            {
                for (int l = i - 1; l < i + 2; l++)
                {
                    for (int m = j - 1; m < j + 1; m++)
                    {
                        sum1 += image[l][m].rgbtRed;
                        sum2 += image[l][m].rgbtGreen;
                        sum3 += image[l][m].rgbtBlue;
                    }
                }
                image[i][j].rgbtRed = round(sum1 / 6);
                image[i][j].rgbtGreen = round(sum2 / 6);
                image[i][j].rgbtBlue = round(sum3 / 6);
            }
        }
    }
    return;
}
