// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 677;

//To count the total no. of words loaded in dictionary
unsigned int wordcount = 0;

// Hash table
node *table[N];

//to check if string is alphanumeric
bool checklower(const char *word);

//to check if string has an apostrophe in it
bool checkapos(const char *word);

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    //printf("%s", word);
    int k = hash(word);
    for (node *n = table[k]; n != NULL; n = n->next)
    {
        if (strcasecmp(word, n->word) == 0)
        {
            return true;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    int index;
    char str[LENGTH + 1];
    strcpy(str, word);
    for (int i = 0; i < strlen(str); i++)
    {
        str[i] = tolower(str[i]);
    }
    if (strlen(str) == 1)
    {
        index = 676;
    }
    else if ((isalpha(str[0]) != 0) && (isalpha(str[1]) != 0))
    {
        index = (26 * (str[0] - 97)) + (str[1] - 97);
    }
    else
    {
        index = 676;
    }
    //printf("%i\n", index);
    return index;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    //opening the dictionary file
    FILE *f = fopen(dictionary, "r");
    //checking for valid file
    if (f == NULL)
    {
        return false;
    }
    char word[LENGTH + 1];
    //loop over word by word
    while (fscanf(f, "%s", word) != EOF)
    {
        //allocate new node
        node *n = malloc(sizeof(node));
        //check if memory is available for node
        if (n == NULL)
        {
            return false;
        }
        //fill values in node
        strcpy(n->word, word);
        n->next = NULL;
        //find the appropriate linked list corresponding to new node
        int k = hash(word);
        // insert new node into the start of the linked list
        if (table[k] == NULL)
        {
            table[k] = n;
        }
        else
        {
            n->next = table[k];
            table[k] = n;
        }
        wordcount++;
    }
    fclose(f);
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return wordcount;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    //to check if true/false
    int flag = 0;
    //to loop over each linked list
    for (int i = 0; i < N; i++)
    {
        //to free ith list
        while (table[i] != NULL)
        {
            node *tmp = table[i];
            table[i] = table[i]->next;
            free(tmp);
        }
        if (table[i] == NULL)
        {
            flag = 1;
        }
        else
        {
            flag = 0;
        }
    }
    if (flag == 1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool checklower(const char *word)
{
    for (int i = 0; i < strlen(word); i++)
    {
        if (islower(word[i]) == 0)
        {
            return false;
        }
    }
    return true;
}

bool checkapos(const char *word)
{
    for (int i = 0; i < strlen(word); i++)
    {
        if (word[i] == '\'')
        {
            return true;
        }
    }
    return false;
}