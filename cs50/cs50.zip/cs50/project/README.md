# Focus Assist Bot
#### Video Demo: https://youtu.be/h-ksgm1NhLs
#### Description: A discord bot to improve focus during work

This bot was written in the Python language with the help of Discord API

##### The files used to make the bot:
1. botdata.py
2. mainbot.py
3. bot3.db

###### botdata.py
This is a python module with only one statement written in it. A string named `TOKEN` has been initialized inside this file. This is a very important
statement, as every bot in discord has a unique token, which cannot be revealed. Hence, for security purposes, the bot's token has been hidden inside
the module in the variable `TOKEN`. This token value can be accessed by importing this file as a module and using the syntax `botdata.TOKEN`


###### mainbot.py
This is the file that contains all the code for the bot and its features.

List of imported modules:

`discord`
The Discord API provides a module named discord that helps establish a connection between Discord's application and the bot application, along with
several other functionality.

`botdata`
This module contains the bot's unique token which is used to run the bot application.

`sqlite3`
This module contains several functions and attributes that help create, edit, manage and delete databases.

`datetime`
This module contains several functions and attributes that help to perform operations and manipulate dates and times.

`requests`
This module contains several functions and attributes that help perform HTTP requests from inside a Python program and manipulate the results.

`asyncio`
This module contains several functions and attributes that help to work with asynchronous functoins and event loops.

`discord.ext`
This module is Discord's extension module that helps to create and enrich a bot with features.

The bot object is created using the `discord.ext.commands.Bot()` constructor.

The bot is run as follows :
```client.run(botdata)```

The default help command provided by `discord.py` has been deleted and overriden by defining a custom help function as shown
```client.remove_command("help")```

`RANKS` is a tuple that contains all the possible ranks a user may attain by focusing more and more, in ascending order.

`FOCUSING` is a dictionary that is used to store the timer status of users who are usinng the countdown timer

`returnexp` is a function that takes the experience points of a user `exp` and returns the corresponding rank of the user from `RANKS`

All the bot commands and events have been defined using decorators provided by `discord.py`

`on_ready` is an event function in `discord.py` provided by default. It is executed when the bot has loaded all the necessary information and has
gone online.

`help` is a command that lists all the available commands in the bot and how to use them in the form of an embed. The code could have been designed
better by storing all the details of the commands in a data structure or database. But the embed are cleaner style wise and hence the help command
has mostly been hardcoded.

`create` is a command that makes an 'account' for the user by making an entry in the `users` table.

`profile` is a command that displays the user's details by performing a `SELECT` query ono the `users` table and displaying it as an embed.

`startrun` starts a new work session if it doesn't already exist. It creates an entry in the `focusing` table and stores the time at which the
session was started.

`stoprun` stops the ongoing work session (if any). It deletes the entry made by `startrun` in `focusing`. It also calculates the total time spent
by subtracting the end time and the start time. It displays the total time worked as an embed, and updates the `exp` column of `users`.

`timer` takes an argument `mins` that: i) starts a countdown timer for `mins` minutes when `mins` is a positive integer (by making an entry in
`focusing` and storing the time in `FOCUSING`), or, ii) ends the ongoing timer when `mins` is the string "stop" (by deleting the entry made in
`focusing`). Otherwise, it does not respond.

`todo` performs a `SELECT` query on the `todo` table and displays the user's to-do list as an embed.

`todoadd` takes 2 arguments, a string `task` and a positive integer `pos`, adds an entry in the `todo` table and inserts `task` into the to-do list
at `pos` position.

`tododel` takes an argument `pos`, a positive integer, and deletes the task at `pos` position in the to-do list by executing `DELETE` queries on the
`todo` table.

`inspire` makes an HTTP response to zenquotes.io's API (using `get` function under `requests` module) which returns a JSON array. This array is
parsed by the `json` function in `requests` and the quote is sent as an embed.

`delete` is a command that deletes the user's 'account' by deleting the entry made by `create` in the `users` table.


###### bot3.db
A database file that contains the information of the users of the bot application.
It consists of 3 tables:

1. users
A table used to store the details of each user
This table consists of the following columns:
id - an integer that is the primary key for the table
username - a string of text that is the user's Discord username. This field has to be unique cannot be NULL
guildname - a string of text that is the user's Discord server in the user's account was created
exp - a positive real number that stores the number of seconds spent focusing using the bot

2. focusing
A table used to store details of the ongoing work session
This table consists of the following columns:
num - an integer that is the primary key for the table
username - a string of text that is the user's Discord username. This field has to be unique cannot be NULL
starttime - a string of text that contains details of the ongoing work session

3. todo
A table used to store the tasks and to-do lists of each user
This table consists of the following columns:
num - an integer that is the primary key for the table
username - a string of text that is the user's Discord username. This field cannot be NULL
taskid - an integer that is the position of the task in the to-do list
task - a string of text that is the name of the task