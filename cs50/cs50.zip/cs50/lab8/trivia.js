document.addEventListener("DOMContentLoaded", function(){
    // to change button color to green when right answer clicked
   var ob1 = document.querySelector(".right");
    ob1.addEventListener("click", function(){
        ob1.style.backgroundColor = "green";
        document.querySelector("#feedback1").innerHTML = "Correct!";
    });

    var ob2 = document.querySelectorAll(".wrong");
    for (let i = 0; i < ob2.length; i++)
    {
        ob2[i].addEventListener("click", function(){
            ob2[i].style.backgroundColor = "red";
            document.querySelector("#feedback1").innerHTML = "Wrong!";
        });
    }

    document.querySelector("#Check").addEventListener("click", function(){
        var userans = document.querySelector("#userans").value;
        if (userans == "1989")
        {
                document.querySelector(".txtans").style.backgroundColor = "green";
                document.querySelector("#feedback2").innerHTML = "Correct!";
        }

        else
        {
                document.querySelector(".txtans").style.backgroundColor = "red";
                document.querySelector("#feedback2").innerHTML = "Wrong!";
        }
    });
});