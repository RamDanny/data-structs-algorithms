#include <cs50.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

// to judge the grade of a paragraph of text
int main(void)
{
    string text = get_string("TEXT: ");
    int l = 0, s = 0, w = 0;
    float index;
    // to count the no. of letters, words, and sentences
    for (int i = 0; text[i] != '\0'; i++)
    {
        if (isalpha(text[i]) != 0)
        {
            l++;
        }
        else if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            s++;
            if (text[i + 1] == '\0')
            {
                w++;
            }
        }
        else if (text[i] == ' ')
        {
            w++;
        }
    }
    // to calculate the grade index
    float L = l * 100 / w, S = s * 100 / w;
    index = 0.0588 * L - 0.296 * S - 15.8;
    if (round(index) < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (round(index) > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", (int)(round(index)));
    }
}