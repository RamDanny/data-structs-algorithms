#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

// to encode plaintext via caesar shift
int main(int argc, string argv[])
{
    //to check for the correct command-line arguments
    if (argc == 2)
    {
        printf("Success\n");
        printf("%s\n", argv[1]);
        int flag = 1;
        for(int i = 0; argv[1][i] != '\0'; i++)
        {
            if (isdigit(argv[1][i]) == 0)
            {
                flag = 0;
            }
        }
        if (flag == 1)
        {
            // to encode the plaintext
            int k = atoi(argv[1]);
            string pt = get_string("plaintext: ");
            for(int j = 0; pt[j] != '\0'; j++)
            {
                if (islower(pt[j]) != 0)
                {
                    pt[j] = (((pt[j] - 'a') + k) % 26) + 'a';
                }
                else if (isupper(pt[j]) != 0)
                {
                    pt[j] = (((pt[j] - 'A') + k) % 26) + 'A';
                }
            }

            printf("ciphertext: %s\n", pt);
        }
        else
        {
            printf("Usage: ./caesar key");
            return 1;
        }
    }
    else
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    return 0;
}