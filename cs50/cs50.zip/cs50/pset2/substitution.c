#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

// to encrypt plaintext by a substitution cipher
int main(int argc, string argv[])
{
    // to check for a valid key
    if (argc == 2)
    {
        int flag = 1;
        int i;
        for (i = 0; argv[1][i] != '\0'; i++)
        {
            if (isalpha(argv[1][i]) == 0)
            {
                flag = 0;
            }
        }
        string k = argv[1];
        int counter = 0;
        char c = 'a';
        for (int l = 0; k[l] != '\0'; l++)
        {
            k[l] = tolower(k[l]);
        }
        for (int m = 0; m < 26 && counter < 2; m++)
        {
            counter = 0;
            c += m;
            for (int n = 0; k[n] != '\0'; n++)
            {
                if (k[n] == c)
                {
                    counter++;
                }
            }
        }
        // to manipulate ascii values for encryption
        if (flag == 1 && i == 26 && counter < 2)
        {
            string pt = get_string("plaintext:");
            for (int j = 0; pt[j] != '\0'; j++)
            {
                if (islower(pt[j]) != 0)
                {
                    pt[j] = tolower(k[pt[j] - 97]);
                }
                else if (isupper(pt[j]) != 0)
                {
                    pt[j] = toupper(k[pt[j] - 65]);
                }
            }
            printf("ciphertext:%s\n", pt);
        }
        else
        {
            printf("Key must contain 26 alphabets each appearing once.\n");
            return 1;
        }
    }
    else
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    return 0;
}