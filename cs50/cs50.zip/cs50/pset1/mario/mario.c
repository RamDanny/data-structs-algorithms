#include <cs50.h>
#include <stdio.h>

int getposint(void);

int main(void)
{
    // to print mario's pyramid with user-input number of rows
    int m = getposint();
    for(int i = 1; i <= m; i++)
    {
        for(int j = 0; j < m-i; j++)
        {
            printf(" ");
        }
        for(int j = 0; j < i; j++)
        {
            printf("#");
        }

        printf(" ");
        printf(" ");

        for(int j = 0; j < i; j++)
        {
            printf("#");
        }

        printf("\n");
    }
}

// gets a positive integer from user
int getposint(void)
{
    int n;
    do
    {
        n = get_int("Enter a positive integer between 1 and 8: ");
    }
    while (n < 1 || n > 8);
    return n;
}