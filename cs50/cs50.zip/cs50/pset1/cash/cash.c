#include <cs50.h>
#include <stdio.h>
#include <math.h>

float get_change(void);

// to print no. of coins returned for user-input amount of change
int main(void)
{
    float change = get_change();
    int pennies = round(change * 100);
    int coins = 0;
    int temp;

    // to calculate the no. of of coins
    temp = pennies / 25;
    coins += temp;
    pennies -= 25 * temp;
    temp = pennies / 10;
    coins += temp;
    pennies -= temp * 10;
    temp = pennies / 5;
    coins += temp;
    pennies -= 5 * temp;
    coins += pennies;

    printf("The no. of coins is\n%i\n", coins);
}

// to get the amount of change required
float get_change(void)
{
    float ch;
    do
    {
       ch = get_float("Enter the change to return: ");
    }
    while (ch < 0);
    return ch;
}