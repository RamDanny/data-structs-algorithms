#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // To say hello to the user when they enter their name
    printf("hello, %s\n", get_string("What is your name? "));
}